package com.coforge.SpringEx.SpringJDBC.service;

import com.coforge.SpringEx.SpringJDBC.entity.Laptop;

public interface LaptopService {
	public void addLaptop(Laptop laptop);
	   public void editLaptop(Laptop laptop, int serialNo);
}
